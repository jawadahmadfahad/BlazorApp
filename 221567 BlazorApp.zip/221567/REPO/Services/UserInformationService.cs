﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using System.Collections.Generic;
using ENTITIES;
using DAL;
using REPO.iServices;

namespace REPO.Services
{
    public class UserInformationService : iUserInformationService
    {
        private readonly UserInformation _dal = new();

        public void CreateUser(ModelUserInformation user)
        {
            _dal.CreateUser(user);
        }

        public void UpdateUser(ModelUserInformation user)
        {
            _dal.UpdateUser(user);
        }

        public void DeleteUser(int userId)
        {
            _dal.DeleteUser(userId);
        }

        public ModelUserInformation? GetUserById(int userId)
        {
            return _dal.GetUserById(userId);
        }

        public IEnumerable<ModelUserInformation> GetAllUsers()
        {
            return _dal.GetAllUsers();
        }
    }
}