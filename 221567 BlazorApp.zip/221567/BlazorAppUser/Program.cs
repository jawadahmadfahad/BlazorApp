using BlazorAppUser.Components;
using REPO.Services;
using REPO.iServices;



var builder = WebApplication.CreateBuilder(args);



// Register both interface and concrete class
builder.Services.AddScoped<iUserInformationService, UserInformationService>();
builder.Services.AddScoped<UserInformationService>();

// Add services to the container.
builder.Services.AddRazorComponents()
    .AddInteractiveServerComponents();

var app = builder.Build();

// Configure the HTTP request pipeline.
if (!app.Environment.IsDevelopment())
{
    app.UseExceptionHandler("/Error", createScopeForErrors: true);
}

app.UseStaticFiles();
app.UseAntiforgery();

app.MapRazorComponents<App>()
    .AddInteractiveServerRenderMode();

app.Run();
