﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


using ENTITIES;

namespace REPO.iServices
{
    public interface iUserInformationService
    {
        void CreateUser(ModelUserInformation user);
        void UpdateUser(ModelUserInformation user);
        void DeleteUser(int userId);
        ModelUserInformation? GetUserById(int userId);
        IEnumerable<ModelUserInformation> GetAllUsers();
    }
}