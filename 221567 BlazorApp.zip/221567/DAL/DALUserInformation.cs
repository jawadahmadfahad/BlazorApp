﻿using System.Collections.Generic;
using System.Linq;
using ENTITIES;

namespace DAL
{
    public class UserInformation
    {
        public void CreateUser(ModelUserInformation user)
        {
            // Implementation will go here
        }

        public void UpdateUser(ModelUserInformation user)
        {
            // Implementation will go here
        }

        public void DeleteUser(int userId)
        {
            // Implementation will go here
        }

        public ModelUserInformation? GetUserById(int userId)
        {
            // Implementation will go here
            return null;
        }

        public IEnumerable<ModelUserInformation> GetAllUsers()
        {
            // Implementation will go here
            return Enumerable.Empty<ModelUserInformation>();
        }
    }
}